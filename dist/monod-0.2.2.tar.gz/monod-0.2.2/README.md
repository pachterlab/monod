# Monod: a package for CME inference from seq data

Write a readme here

